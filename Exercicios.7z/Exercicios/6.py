#Algoritmo para criar uma lista usando range com 100 elementos e imprimi-la.
lista = []

for numero in range(100):
    lista.append(numero+1)
    # print(lista[:])


print(lista[:])