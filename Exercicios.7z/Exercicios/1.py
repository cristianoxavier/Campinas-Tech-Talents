#Algoritmo para ligar um carro (Imprimir a sequência para ligar um carro)

print("Voce deseja ligar o carro?")
ligar = input("Digite sim ou não. ")

if ligar == "sim":
    print("Ligou")
else:
    print("Não ligou")

