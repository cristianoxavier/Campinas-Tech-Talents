'''
Elabore um algoritmo em Python que:
a) Primeiro exiba uma mensagem de boas vindas;
b) Pergunte o nome do usuário;
c) Exiba uma mensagem dizendo uma mensagem de olá
seguida pelo nome do usuário seguida por outra mensagem
fazendo um elogio.
'''

print("Bem vindo! \n Por favor, informe o seu nome: ")
nome = input()

print(f"Ola {nome}, obrigado pela sua ilustre presença!")
